//: Playground - noun: a place where people can play

import UIKit

class Car {
    
    var color = ""
    var wheels = 0
    var make = ""
    var model = ""
    
    func dirve() {
        print("Vrooomm")
    }
    
    func brake () {
        //stop
    }
    
    func turn () {
        //turn
    }
}

let car = Car()

car.color = "Red"
car.wheels = 4

car.dirve()

//Property Observers
class Developer {
    var firstName : String
    var lastName : String
    var position = "Junior Developer"
    
    
    var salary : Double {
        willSet {
            if newValue >= 120000 {
                position = "Senior Developer"
            }
        }
        
    }
    
    var monthlySalary: Double {
        
        get {
            //called when accessing variable
            return salary / 12
        }
        set {
            //called when setting variable value
            salary = newValue * 12
        }
    }
    
    init() {
        firstName = ""
        lastName = ""
        salary = 0
    }
    
    init(firstName : String, lastName: String) {
        self.firstName = firstName
        self.lastName = lastName
        salary = 0
    }
    
    init(first :String, last :String, salary : Double) {
        firstName = first
        lastName = last
        self.salary = salary
    }
    func requestRaise(inTheAmountOf amount: Double){
        salary += amount
    }
}
let dev = Developer(first: "Vince", last: "Hunter", salary: 100000)


dev.requestRaise(inTheAmountOf: 10000)
print(dev.position)

dev.requestRaise(inTheAmountOf: 10000)
print(dev.position)




//Structures

struct DevStruct {
    
    var firstName :String
    var lastName : String
    var position = "Junior Developer"
    
    
    var salary : Double {
        willSet {
            if newValue >= 120000 {
                position = "Senior Developer"
            }
        }
        
    }
    
    var monthlySalary: Double {
        
        get {
            //called when accessing variable
            return salary / 12
        }
        set {
            //called when setting variable value
            salary = newValue * 12
        }
    }
    
    
    init() {
        firstName = ""
        lastName = ""
        salary = 0
    }
    
    init(firstName : String, lastName: String) {
        self.firstName = firstName
        self.lastName = lastName
        salary = 0
    }
    
    init(first :String, last :String, salary : Double) {
        firstName = first
        lastName = last
        self.salary = salary
    }
    
    mutating func requestRaise(inTheAmountOf amount: Double){
        salary += amount
    }
    
}

var devStruct = DevStruct(first: "Vince", last: "H", salary: 100000)
var copyDevStruct = devStruct

devStruct.firstName = "JonnyB"
copyDevStruct.firstName = "Fernando"

//print(devStruct.firstName)
//
//print(copyDevStruct.firstName)

let passedDev = dev

dev.firstName = "JonnyB"
passedDev.firstName = "Sally"
print(dev.firstName)
print(passedDev.firstName)






