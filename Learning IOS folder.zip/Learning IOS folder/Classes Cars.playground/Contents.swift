//: Playground - noun: a place where people can play

import UIKit

class Car {
    
    var color = ""
    var wheels = 0
    var make = ""
    var model = ""
    
    
    func drive() {
        print("Vrooom")
    }
    
    
    func breaks() {
       //turn
    }
    
    func turn() {
        //turn
    }
}
