//: Playground - noun: a place where people can play

import UIKit

enum SubType : Int {
    case none = 0
    case bronze
    case silver
    case gold
}

//var subtype = SubType.silver

//var subtype :Type = SubType.silver
var subtype :SubType = .silver

if subtype == .silver {
    //Perform some action for silver subs
    print("This user is a silver")
}

switch subtype {
case .none:
    print("None")
case .bronze :
    print("Bronze")
case .silver:
    print("Silver")
case .gold :
    print("Gold")
   }



// downloaded user account and subtype property = 2

var subscriberType = 2

var subType: SubType!

switch subscriberType {
case 1:
    subtype = .bronze
case 2:
    subtype = .silver
case 3:
    subtype = .gold
default:
    subtype = SubType.none
}
print(subType)
