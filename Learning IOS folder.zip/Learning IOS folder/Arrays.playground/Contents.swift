//: Playground - noun: a place where people can play

import UIKit

var cards = ["Ace", "King","Queen","Joker"]
cards[0]

cards.append("Jack")
print(cards)

cards.remove(at: 1)

cards

cards.insert("King", at: 4)
cards[1] = "Jester"

print(cards)

let fingers = ["Thumb"]
fingers
