//: Playground - noun: a place where people can play

import UIKit

var optionalString : String?


print(optionalString)

optionalString = "Vince"

print(optionalString)


var a : Int?
var b : Int?

a = 4
b = 6
//forced unwrapping
let sum = a! + b!

//optional binding
if let number = a {
    //here we can use number
    print(number)
}


func getnumberA(){

// guard let Optonal binding
    // **guard let cannot be returned outside a function

//guard let number = a else{ return }
    
    guard let a = a , let b = b else { return }
    print(a+b)
    
}

//nil coalesing operator

var name:String? = "Vince"

print(name ?? "Bill")

var actualName = name ?? "Fred"

var num  = a ?? 0
