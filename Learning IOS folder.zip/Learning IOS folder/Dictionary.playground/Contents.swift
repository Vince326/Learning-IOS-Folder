//: Playground - noun: a place where people can play

import UIKit

var screenSizesInInches:Dictionary<String, Double> = ["iPhone 7": 4.7, "iPhone 7+": 5.2, "iPad Pro": 12.9]

screenSizesInInches["iPhone 7"]
screenSizesInInches["iPhone 7+"] = 5.5

screenSizesInInches["iPad Air 2"] = 9.7

screenSizesInInches.removeValue(forKey: "iPhone 7")

print(screenSizesInInches)

 // Functions

//A function is a set of instructions that accomplish one specific task
//Function with no parameter
func declareName() {
    print("Vince")
}

declareName()
//Function with a parameter
func declare(name: String){
    print(name)
}

declare(name: "Vinny")
//Function with parameters and return value
func createFullName(firstName:String, lastName:String) -> String{
    
    return firstName + " " + lastName
  
}

let fullName = createFullName(firstName: "James", lastName: "Williams")

print(fullName)



//Control Flow and Loops

//For Loop

let names = ["Peter", "Paul","Mary", "Frank"]

for name in names {
    print("Hello, \(name)!")
}

let numberOfLegs = ["Spider":8,"Dog":4, "Human":2]

for (animalType, legCount) in numberOfLegs{
    print("\(animalType)s have \(legCount) legs.")
}

for index in 1...5 {
    print("\(index) times 5 is equal to \(index * 5)")
}

for index in 0..<4 {
    print(names[index])
}

//While Loops

var score = 0
var diceRoll = 0

while score < 20 {
    diceRoll = Int(arc4random_uniform(6))
    print("DICE ROLL:", diceRoll, "\n")
    
    if diceRoll <= 4 {
        score += 1
        print("SCORE:", score)
    } else if diceRoll >= 5 {
        if score > 0 {
            score =  score - 1
            print("SCORE:", score)
        }
        score -= 1
        print("SCORE:", score)
    }
}

